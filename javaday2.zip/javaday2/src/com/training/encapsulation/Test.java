package com.training.encapsulation;

public class Test {
    public static void main(String[] args) {
        /**
         * Creating objects by invoking No arg construtor
         */
        Customer customer=new Customer();
        Customer customer1=new Customer();
        customer.setId(111);
        customer.setFirstName("Sahana");
        customer.setLastName("Bharadawaj");
        customer1.setId(112);
        customer1.setFirstName("Mariyam");
        customer1.setLastName("Saman");
        System.out.println(customer);
        System.out.println(customer1);
        Customer customer2=new Customer();
        customer2.setId(222);
        customer2.setFirstName("Sweety");
        customer2.setLastName("Singh");
        System.out.println(customer2);

        Customer[] customers=new Customer[3];
        customers[0]=customer;
        customers[1]=customer1;
        customers[2]=customer2;
        System.out.println(customers);
        for(Customer c:customers){
            System.out.println(c);
        }

        System.out.println("**************************");
        System.out.println(customer.getId());
        System.out.println(customer.getFirstName());
        System.out.println(customer.getLastName());

    }
}
