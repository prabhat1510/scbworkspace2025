package com.training.usecase;

public class Customer {
    private int cutsomerid;
    private String name;
    private String email;
    private String contact;
    private String accountType;

    public Customer() {
    }

    public Customer(int cutsomerid, String name, String email, String contact, String accountType) {
        this.cutsomerid = cutsomerid;
        this.name = name;
        this.email = email;
        this.contact = contact;
        this.accountType = accountType;
    }

    public int getCutsomerid() {
        return cutsomerid;
    }

    public void setCutsomerid(int cutsomerid) {
        this.cutsomerid = cutsomerid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "  Customer Id=" + cutsomerid +
                ", Customer name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", Customer contact='" + contact + '\'' +
                ", accountType='" + accountType + '\'' +
                '}';
    }
}
