package com.training.usecase;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        List<Customer> customers = new ArrayList<Customer>();
        while(true){
        System.out.println("*******Welcome to ELly Bank*******");
        System.out.println("Please enter your choice: ");
        System.out.println("1. for Add new Customer");
        System.out.println("2. for Display Customers");
        System.out.println("3. for Search Customer");
        System.out.println("4. for Delete Customer");
        System.out.println("5. for Exit the bank application");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        switch(choice){
                case 1:
                        //Logic for Add new Customer
                        System.out.println("Enter Customer Id: " );
                        int id = sc.nextInt();
                        System.out.println("Enter Customer name: " );
                        String name = sc.next();
                        System.out.println("Enter Customer email: " );
                        String email = sc.next();
                        System.out.println("Enter Customer contact: ");
                        String contact = sc.next();
                        System.out.println("Enter Customer account type: ");
                        String accountType = sc.next();

                        Customer c = new Customer();
                        c.setCutsomerid(id);
                        c.setName(name);
                        c.setEmail(email);
                        c.setContact(contact);
                        c.setAccountType(accountType);
                        customers.add(c);
                        break;
                case 2:
                        //Logic for Display Customers
                        for (Customer c1:customers){
                            System.out.println(c1);
                        }
                        break;
                case 3:
                        //Logic for Search Customer
                        System.out.println("Enter Customer Id to be searched: ");
                        int cid = sc.nextInt();
                        for (Customer c1:customers){
                            if(c1.getCutsomerid() == cid){
                                System.out.println("Customer found details are "+c1);
                            }
                        }
                        break;
                case 4:
                        //Logic for Delete Customer
                        System.out.println("Enter Customer Id to be deleted: ");
                        int custId = sc.nextInt();
                        //customers.remove(sc.nextInt());
                        Iterator itr = customers.iterator();
                        while(itr.hasNext()){
                            if( custId == ((Customer)itr.next()).getCutsomerid()){
                                  itr.remove();
                            }
                        }
                        System.out.println("Customer deleted successfully");
                        break;
                case 5:
                        System.out.println("Bye Bye !!!");
                        System.exit(0);
                        break;
                default:
                        System.out.println("Invalid choice");
                        break;
        }
        }
        //
        //customers.add(customer);
    }
}
