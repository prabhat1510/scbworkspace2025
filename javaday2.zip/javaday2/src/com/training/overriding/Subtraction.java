package com.training.overriding;

public class Subtraction extends Calculate{

    public int sub(int a,int b){
       int result = calculate(a,b);
        System.out.println(result);
        return result;
    }
    @Override
    public int calculate(int a,int b){
        int result = a-b;
        return result;
    }

}
