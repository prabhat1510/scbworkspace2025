package com.training.overriding;

public class SubtractionTest{
    public static void main(String[] args) {
        Subtraction s=new Subtraction();
        Calculate c=new Calculate();
        System.out.println(s.calculate(8,2));
        System.out.println(c.calculate(15,10));
        Calculate c1=new Subtraction();
        System.out.println(c1.calculate(18,2));
    }


}
