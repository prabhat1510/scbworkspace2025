package com.training.overriding;

public class Calculate {

    public int calculate(int a, int b){
        int sum=a+b;
        System.out.println("Calculate called"+sum);
        return sum;
    }
}
