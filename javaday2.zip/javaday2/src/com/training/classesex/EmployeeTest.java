package com.training.classesex;

public class EmployeeTest {

    public static void main(String[] args) {
        Employee employee = new Employee();
        employee.setId(111);
        employee.setFirstName("Kunal Nigam");
       // String companyName = Employee.getCompanyName();
        //System.out.println(companyName);
        System.out.println(Employee.companyName);
        System.out.println(employee.getFirstName());
        System.out.println(employee.getId());
        displayDetails();//Calling static method from static method
        //displayMessage();//Calling non static method from static method --Error
        EmployeeTest employeeTest = new EmployeeTest();
        employeeTest.displayMessage();
    }

    public static void displayDetails(){
        System.out.println("I am static method");
    }
    public void displayMessage(){
        System.out.println("Hello All--I am non static method");
    }
}
