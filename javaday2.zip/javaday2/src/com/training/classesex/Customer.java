package com.training.classesex;

import java.time.LocalDate;

public class Customer {
    /**
     * State of the class or Instance variable
     * or Fields or Properties
     */
    int custId;
    String custName;
    String custEmail;
    String custPhone;
    LocalDate custBirthday;
    double custSalary;

    public Customer(int custId, String custName, String custEmail, String custPhone, LocalDate custBirthday, double custSalary) {
        this.custId = custId;
        this.custName = custName;
        this.custEmail = custEmail;
        this.custPhone = custPhone;
        this.custBirthday = custBirthday;
        this.custSalary = custSalary;
    }

    public Customer() {

    }

    //Instance methods
    void displayDetails() {
        System.out.println("Customer ID: " + this.custId);
        System.out.println("Customer Name: " + this.custName);
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustEmail() {
        return custEmail;
    }

    public void setCustEmail(String custEmail) {
        this.custEmail = custEmail;
    }

    public String getCustPhone() {
        return custPhone;
    }

    public void setCustPhone(String custPhone) {
        this.custPhone = custPhone;
    }

    public LocalDate getCustBirthday() {
        return custBirthday;
    }

    public void setCustBirthday(LocalDate custBirthday) {
        this.custBirthday = custBirthday;
    }

    public double getCustSalary() {
        return custSalary;
    }

    public void setCustSalary(double custSalary) {
        this.custSalary = custSalary;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "custId=" + custId +
                ", custName='" + custName + '\'' +
                ", custEmail='" + custEmail + '\'' +
                ", custPhone='" + custPhone + '\'' +
                ", custBirthday=" + custBirthday +
                ", custSalary=" + custSalary +
                '}';
    }
}
