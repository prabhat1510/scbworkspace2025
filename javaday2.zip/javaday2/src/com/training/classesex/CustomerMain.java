package com.training.classesex;

import java.time.LocalDate;
import java.util.Scanner;

public class CustomerMain {
    public static void main(String[] args) {
        //Creating a customer class object by invoking the constructor
        Customer customer = new Customer(); //No arg constructor or Default Constructor
        System.out.println(customer);
        customer.displayDetails();
        //Creating a customer class object by invoking parameterized constructor
        Customer customer1 = new Customer(1,"Rahul","rahul@gmail.com","9999111555", LocalDate.of(2000,10,15),5555.55);
        System.out.println(customer1);
        customer1.displayDetails();

        Customer customer2 = new Customer();
        Scanner sc = new Scanner(System.in);
        //Integer input
        System.out.println("Enter Customer ID: ");
        int custId =sc.nextInt();
        sc.nextLine();
        //String input
        System.out.println("Enter Customer Name: ");
        String  custName =sc.nextLine();
        System.out.println("Enter Customer Email: ");
        String custEmail =sc.nextLine();

        customer2.setCustId(custId);
        customer2.setCustName(custName);
        customer2.setCustEmail(custEmail);
        System.out.println(customer2);


    }
}
