package com.training.relationship;

public class Student {
    private String name;
    private int age;

    private Address address;
    private Address homeAddress;

    public Student(String name, int age, Address address, Address homeAddress) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.homeAddress = homeAddress;
    }

    public Student() {
    }

    public Student(String name, int age, Address address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Address getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(Address homeAddress) {
        this.homeAddress = homeAddress;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", address=" + address +
                ", homeAddress=" + homeAddress +
                '}';
    }
}
