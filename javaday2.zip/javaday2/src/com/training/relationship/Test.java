package com.training.relationship;

public class Test {
    public static void main(String[] args) {

    }
}
