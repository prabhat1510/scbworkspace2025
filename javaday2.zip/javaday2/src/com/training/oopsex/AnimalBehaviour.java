package com.training.oopsex;

public interface AnimalBehaviour {
    //Decalartion or abstract method
    public void specialBehaviour ();
    /**
     * In Java we cannot have definition of a method
     * inside an interface only declaration is allowed
     * But since Java 8 we can method with body and these methods must be
     * static or default
     */
}
