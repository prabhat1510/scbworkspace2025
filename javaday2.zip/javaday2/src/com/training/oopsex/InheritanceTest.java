package com.training.oopsex;

public class InheritanceTest {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.bark();
        dog.eat();
    }
}
