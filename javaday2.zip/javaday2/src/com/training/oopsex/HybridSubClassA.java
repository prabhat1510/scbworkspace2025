package com.training.oopsex;

public class HybridSubClassA implements  HybridSuperClass{
    public void specialBehaviourA(){
        System.out.println("Special behaviour.... || HybridSubClassA");
    }

    @Override
    public void specialBehaviour() {
        System.out.println("Special behaviour.... || implemented inside HybridSubClassA");
    }
}
