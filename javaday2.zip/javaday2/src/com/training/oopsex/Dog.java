package com.training.oopsex;
//Child Class or Derived Class or Sub Class
public class Dog  extends Animal{
    void bark(){
        System.out.println("Barking...");
    }
}
