package com.training.oopsex;

public class HybridChildClass extends HybridSubClassA implements HybridSubClassB{
    @Override
    public void specialBehaviourB() {
        System.out.println("special behaviour.... || HybridSubClassB inside Child Class");
    }
}
