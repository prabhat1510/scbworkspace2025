package com.training.oopsex;
//Super Class or Base Class or Parent Class
public class Animal {
    void eat(){
        System.out.println("Animal is eating...");
    }
}
