package com.training.oopsex;

public class Labra extends Dog{
    void sleep(){
        System.out.println("Sleeping...");
    }
}
