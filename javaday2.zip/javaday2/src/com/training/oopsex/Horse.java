package com.training.oopsex;
//Multiple Inheritance using interfaces
public class Horse extends Animal implements AnimalBehaviour{

    @Override
    public void specialBehaviour() {
        System.out.println("Special behaviour....");
    }
    public void kneighBehaviour(){
        System.out.println("Knigh behaviour....");
    }
}
