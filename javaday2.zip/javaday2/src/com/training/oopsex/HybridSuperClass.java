package com.training.oopsex;

public interface HybridSuperClass {
    public void specialBehaviour();
}
