package com.training.oopsex;

public class Cat extends Animal{
    void meow(){
        System.out.println("Meowing...");
    }
}