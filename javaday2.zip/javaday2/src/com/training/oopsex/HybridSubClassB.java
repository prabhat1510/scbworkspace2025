package com.training.oopsex;

public interface HybridSubClassB extends HybridSuperClass{
    public void specialBehaviourB();
}
