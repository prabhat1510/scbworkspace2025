package com.training.springusecasewithjpa.controller;

import com.training.springusecasewithjpa.entities.Customer;
import com.training.springusecasewithjpa.exceptions.CustomerNotFoundException;
import com.training.springusecasewithjpa.exceptions.DataNotFoundException;
import com.training.springusecasewithjpa.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/customer/{id}")
    public Optional<Customer> getCustomersById(@PathVariable Integer id) throws CustomerNotFoundException {
        return customerService.getCustomerById(id);
    }

    @GetMapping("/customers")
    public List<Customer> getAllCustomers() throws DataNotFoundException{
        return customerService.getAllCustomers();
    }
}
