package com.training.springusecasewithjpa.service;



import com.training.springusecasewithjpa.entities.Customer;
import com.training.springusecasewithjpa.exceptions.CustomerNotFoundException;
import com.training.springusecasewithjpa.exceptions.DataNotFoundException;

import java.util.List;
import java.util.Optional;

public interface CustomerService {
    // Listing all customers
    public List<Customer> getAllCustomers() throws DataNotFoundException;
    // Getting one customer details
    public Optional<Customer> getCustomerById(Integer id) throws CustomerNotFoundException;

}
