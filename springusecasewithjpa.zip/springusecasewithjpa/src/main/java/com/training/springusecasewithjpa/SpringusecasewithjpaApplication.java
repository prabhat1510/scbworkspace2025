package com.training.springusecasewithjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringusecasewithjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringusecasewithjpaApplication.class, args);
	}

}
