package com.training.springusecasewithjpa.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Accounts {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;//PRIMARY KEY
    private String accountType;
    private Integer accountNumber;
    private String accountBranch;
    private Double accountBalance;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Integer getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountBranch() {
        return accountBranch;
    }

    public void setAccountBranch(String accountBranch) {
        this.accountBranch = accountBranch;
    }

    public Double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Double accountBalance) {
        this.accountBalance = accountBalance;
    }

    @Override
    public String toString() {
        return "Accounts{" +
                "id=" + id +
                ", accountType='" + accountType + '\'' +
                ", accountNumber=" + accountNumber +
                ", accountBranch='" + accountBranch + '\'' +
                ", accountBalance=" + accountBalance +
                '}';
    }
}
