package com.training.springusecasewithjpa.service;


import com.training.springusecasewithjpa.dao.CustomerRepository;
import com.training.springusecasewithjpa.entities.Customer;
import com.training.springusecasewithjpa.exceptions.CustomerNotFoundException;
import com.training.springusecasewithjpa.exceptions.DataNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository repo;

    @Override
    public List<Customer> getAllCustomers() throws DataNotFoundException {
        return (List<Customer>) repo.findAll();
    }

    @Override
    public Optional<Customer> getCustomerById(Integer id) throws CustomerNotFoundException {
        return repo.findById(id);
    }


}
