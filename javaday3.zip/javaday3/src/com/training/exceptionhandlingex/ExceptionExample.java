package com.training.exceptionhandlingex;

public class ExceptionExample {
    public static void main(String[] args) {
        System.out.println("Learning Exceptions----START--");
        int data =10/0;
        System.out.println("data:"+data );
        System.out.println("Learning Exceptions----END--");
    }
}
