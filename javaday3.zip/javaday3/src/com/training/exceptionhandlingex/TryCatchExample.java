package com.training.exceptionhandlingex;

public class TryCatchExample {
    public static void main(String[] args) {

        System.out.println("Learning Exceptions----START--");
        try {
            int a[] = new int[5];
            //int data = 10 / 0;
            a[5]= 11111;
            a[5]=10/0;
            System.out.println("data:" + a[4]);
        }catch(ArithmeticException e){
            System.out.println("ArithmeticException----START--");
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("ArrayIndexOutOfBoundsException----START--");
        }catch(Exception e){
            System.out.println("Exception----START--");
        }
        finally{
            System.out.println("Finally executed----END--");
        }
        System.out.println("Outside try catch and finally");
    }
}
