package com.training.exceptionhandlingex;

public class ExceptionPropagation {

    public void calculate() throws ArithmeticException,ArrayIndexOutOfBoundsException,NumberFormatException{
        int data =10/0;
        System.out.println("Learning Exceptions----START--");
        throw new ArithmeticException();
    }
}
