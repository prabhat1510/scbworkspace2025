package com.training.exceptionhandlingex;

import java.util.Scanner;

public class InvalidAgeExceptionTest {
    public static void main(String[] args){
        UseOfInvalidAgeEx useOfInvalidAgeEx = new UseOfInvalidAgeEx();
        try {
            useOfInvalidAgeEx.checkEligibility();
        } catch (InvalidAgeException e) {
            System.out.println(e.getMessage());
        }
    }
}
