package com.training.exceptionhandlingex;

public class NullPointerExceptionExample {
    public static void main(String[] args) {
        /**String s = null;
        System.out.println(s.length());**/
        Employee emp1 = new Employee();
        Employee emp2 = new Employee();
        emp2.setId(1);
        emp2.setFirstName("John");
        emp2.setLastName("Doe");
        if(emp1.getFirstName().equals("John") && emp1.getLastName().equals("Doe")){
        System.out.println("Employee ID is " + emp1.getId());
        }

    }
}
