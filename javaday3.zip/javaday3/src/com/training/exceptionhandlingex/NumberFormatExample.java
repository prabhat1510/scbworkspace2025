package com.training.exceptionhandlingex;

public class NumberFormatExample {
    public static void main(String[] args) {
        String firstName = "John";
        int i = Integer.parseInt(firstName);
    }
}
