package com.training.exceptionhandlingex;

import java.util.Scanner;

public class UseOfInvalidAgeEx {

    public void checkEligibility() throws InvalidAgeException {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your age :");
        int age = input.nextInt();
        if(age >= 18){
            System.out.println("Eligible to vote");
        }else{
            //Explicitly throwing an exception
            throw new InvalidAgeException("In eligble to vote enter correct age");
        }
    }
}
