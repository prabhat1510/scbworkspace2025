package com.training.exceptionhandlingex;

public class ExceptionPropagationTest {
    public static void main(String[] args) {
        ExceptionPropagation excep= new ExceptionPropagation();
        try {
            excep.calculate();
        }catch(ArithmeticException e){
            System.out.println("Division by zero exception "+e.getMessage());
        }
    }
}
