package com.training.exceptionhandlingex;

public class InvalidAgeException extends Exception{
    InvalidAgeException(String s){
        super(s);
    }
}
