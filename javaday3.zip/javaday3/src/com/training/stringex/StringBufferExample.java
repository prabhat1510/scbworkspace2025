package com.training.stringex;

public class StringBufferExample {
    public static void main(String[] args) {
        StringBuffer sb=new StringBuffer("Good Morning All !!!");
        System.out.println(sb);
        System.out.println(sb.length());
        sb.append("Please focus ---- :(");
        System.out.println(sb);
        System.out.println(sb.capacity());
        System.out.println(sb.length());
        System.out.println(sb.reverse());
        System.out.println();
        StringBuilder sb1=new StringBuilder("Hello World");

    }
}
