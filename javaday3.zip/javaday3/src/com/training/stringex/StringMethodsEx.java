package com.training.stringex;

import java.util.Arrays;

public class StringMethodsEx {
    public static void main(String[] args) {
                //      0123456789
        String company="East India";

        System.out.println(company.charAt(3));
        System.out.println(company.length());
        System.out.println(company.toUpperCase());
        System.out.println(company.toLowerCase());
        System.out.println(company.substring(2));
        System.out.println(company.substring(2,7));
        System.out.println(company.contains("Inde"));
        System.out.println(company.equalsIgnoreCase("eaSt inDia"));
        System.out.println(company.equals("East India"));
        System.out.println(company.split(" "));
        String[] str=company.split(" ");
        System.out.println(Arrays.toString(str));


    }
}
