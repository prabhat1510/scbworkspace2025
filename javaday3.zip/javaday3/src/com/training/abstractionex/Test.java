package com.training.abstractionex;

public class Test {
    public static void main(String[] args) {
        //'Shape' is abstract; cannot be instantiated
        //Shape shape = new Shape("Red");
        Shape circle = new Circle("Red",2.5);
       double area= circle.area();
        System.out.println(area);

        TestClass testClass = new TestClass();
        testClass.display();
        testClass.displayMessage2();
        testClass.display3();
    }
}
