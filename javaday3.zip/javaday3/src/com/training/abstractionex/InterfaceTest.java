package com.training.abstractionex;

public interface InterfaceTest {
    //public, static and  final
    final int a =10;
    //abstract method
    void display();
    void display3();
    /**static and defaults are introduced in Java 8**/
    public static void  displayMessage(){
        System.out.println("displayMessage static method -- interface example");
    }

    default void displayMessage2(){
        System.out.println("displayMessage2 default method -- interface example");
    }
}
