package com.training.abstractionex;

public class TestClass implements InterfaceTest,InterfaceTwo{
    @Override
    public void display() {
        System.out.println("display method -- interface example");
    }

    @Override
    public void display3() {
        System.out.println("display3  method inside Test Class -- interface example");
    }

    @Override
    public void displayMessage2() {
        System.out.println("Overriding displayMessage2 default method -- interface example");
    }

    @Override
    public void displayInterfaceTwo() {
        System.out.println("displayInterfaceTwo method -- interface example");
    }
}
