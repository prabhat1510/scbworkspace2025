package com.training.abstractionex;

public interface InterfaceTwo {
    public void displayInterfaceTwo();
}
