package com.training.abstractionex;

public abstract class Shape {
    String color;
    //abstract method
    abstract double area();
    //Constructor
    //Abstract class can have the constructor
    public Shape(String color) {
        System.out.println("Shape constructor called");
        this.color = color;
    }
    //getter method -- or concrete method
    public String getColor() {
        return color;
    }
}
