package com.training.abstractionex;

public class Circle  extends Shape {

    double radius;
    public Circle(String color, double radius) {
        super(color);//calling the constructor of the super class
        System.out.println("Inside Circle constructor");
        this.radius = radius;
    }
    @Override
    double area() {
        return Math.PI*Math.pow(radius,2);
    }
}
