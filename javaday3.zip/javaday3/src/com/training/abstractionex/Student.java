package com.training.abstractionex;

public abstract class Student {

    String name;
    abstract void display();
}
