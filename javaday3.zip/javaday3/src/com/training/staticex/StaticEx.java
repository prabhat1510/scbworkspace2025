package com.training.staticex;

public class StaticEx {
    public static void main(String[] args) {
            display();
            StaticEx obj1 = new StaticEx();
            obj1.display2();
    }
    static void display(){
        System.out.println("Display method");
    }

    void display2(){
        display();
    }
}
