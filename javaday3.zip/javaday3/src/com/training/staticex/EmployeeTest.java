package com.training.staticex;

public class EmployeeTest {
    public static void main(String[] args) {
        Employee emp1 = new Employee(101,"John");
        emp1.display();
        Employee emp2 = new Employee(102,"Jane");
        emp2.display();
    }
}
