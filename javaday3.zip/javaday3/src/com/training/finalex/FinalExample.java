package com.training.finalex;

public final class FinalExample {

    public void display() {
        System.out.println("display method -- interface example");
    }
}
