package com.training.finalex;

/*public class FinalExampleClass extends FinalExample{
}*/
public class FinalExampleClass{
    final void display(){
        System.out.println("Display method");
    }
}
