package com.training.finalex;

public class FinalClassExForOverriding extends FinalExampleClass{
    /**
    @Override
    final void display(){
        System.out.println("Display method11111");
    }**/
}
