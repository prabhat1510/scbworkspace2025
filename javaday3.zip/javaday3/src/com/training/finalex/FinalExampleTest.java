package com.training.finalex;

public class FinalExampleTest {
    public static void main(String[] args) {
        final String companyName="Java";
        //companyName="Python";
        display();
    }

    final static void display(){
        System.out.println("Display method");
    }
}
