package com.scb.dao;

import com.scb.model.Customer;
import com.scb.utility.DBConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

//Code to establish connection with DB and execute the query
public class CustomerDAOImpl implements CustomerDAO{
    private final String url = "jdbc:postgresql://localhost:5432/scb2024";
    private final String user = "postgres";
    private final String password = "password";

    @Override
    public String addCustomer(Customer customer) {

        Connection con = null;
        int row;
        try {
            //Connection
            con = DBConnectionUtil.getDBConnection();
            String sql = "INSERT INTO customer VALUES(?,?,?,?)";
            //Prepate statement created
            PreparedStatement ps = con.prepareStatement(sql);
            //Values are assigned
            ps.setInt(1,customer.getCustomerId());
            ps.setString(2, customer.getCustomerName());
            ps.setString(3, customer.getCustomerAddress());
            ps.setString(4, customer.getCustomerPhone());
            //Execute the query
            row =ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if(row>0){
            return "Customer added successfully";
        }else {
            return "Not able to add customer";
        }
    }

    @Override
    public Customer getCustomer(int customerId) {
        Customer customer = new Customer();
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            //Establish the connection
            con = DriverManager.getConnection(url,user,password);
            //Create Statement
            stmt = con.createStatement();
            //Execute the query
            String sqlQuery = "SELECT * FROM customer WHERE id="+customerId;
            rs = stmt.executeQuery(sqlQuery);

            //List<Customer> customers = new ArrayList<Customer>();
            //Accessing the result set data
            if(rs.next()){
                customer.setCustomerId(rs.getInt("id"));//column index 1
                customer.setCustomerName(rs.getString("name"));//column index 2
                customer.setCustomerAddress(rs.getString("address"));//column index 3
                customer.setCustomerPhone(rs.getString("phone"));//column index 4
            }
            /**while (rs.next()) {
                customer.setCustomerId(rs.getInt("id"));//column index 1
                customer.setCustomerName(rs.getString("name"));//column index 2
                customer.setCustomerAddress(rs.getString("address"));//column index 3
                customer.setCustomerPhone(rs.getString("phone"));//column index 4
            }**/
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                //rs.close(); //Close the result set
                stmt.close();//Close the statement
                con.close();//Close the connection
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }

        return customer;
    }

    @Override
    public String updateCustomer(Customer customer) {
        Connection con = null;
        PreparedStatement ps = null;
        int row = 0;
        con=DBConnectionUtil.getDBConnection();
        String sql = "update customer set name=?,address=?,phone=? where id=?";

            try {
                ps=con.prepareStatement(sql);
                ps.setString(1,customer.getCustomerName());
                ps.setString(2,customer.getCustomerAddress());
                ps.setString(3,customer.getCustomerPhone());
                ps.setInt(4,customer.getCustomerId());//Setting the parameter to query
                row = ps.executeUpdate();//exceuting the query
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        if(row>0){
            return "Customer updated successfully";
        }else{
            return "Not able to update customer";
        }
    }

    @Override
    public String deleteCustomer(Integer customerId) {
        Connection con = null;
        PreparedStatement ps = null;
        int row = 0;
        con=DBConnectionUtil.getDBConnection();
        String sql = "DELETE FROM customer WHERE id=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1,customerId);//Setting the parameter to query
            row = ps.executeUpdate();//exceuting the query
            /**ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return "Not able to delete customer";
            }**/
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if(row>0){
            return "Customer deleted successfully";
        }else{
            return "Not able to delete customer";
        }

        //return "Customer deleted successfully";
    }

    @Override
    public List<Customer> getAllCustomers() {
       Connection con = null;
        ResultSet rs = null;
        Statement stmt = null;
       List<Customer> customers = new ArrayList<Customer>();

        //Connection
        con = DBConnectionUtil.getDBConnection();
        try {
            stmt = con.createStatement();
            String sql = "SELECT * FROM customer";
            rs = stmt.executeQuery(sql);
            while(rs.next()){
                Customer customer = new Customer();
                customer.setCustomerId(rs.getInt("id"));
                customer.setCustomerName(rs.getString("name"));
                customer.setCustomerAddress(rs.getString("address"));
                customer.setCustomerPhone(rs.getString("phone"));
                customers.add(customer);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return customers;
    }
}
