package com.scb.service;

import com.scb.model.Customer;

import java.util.List;

public interface CustomerService {
    //Create
    public String addCustomer(Customer customer);
    //Retrieve
    public Customer getCustomer(int customerId);
    //Update
    public String updateCustomer(Customer customer);
    //Delete
    public String deleteCustomer(Integer customerId);

    //Get All Customers
    public List<Customer> getAllCustomers();
}
