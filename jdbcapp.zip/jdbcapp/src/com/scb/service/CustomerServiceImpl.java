package com.scb.service;

import com.scb.dao.CustomerDAO;
import com.scb.dao.CustomerDAOImpl;
import com.scb.model.Customer;

import java.util.List;

public class CustomerServiceImpl implements CustomerService{

    @Override
    public String addCustomer(Customer customer) {
        CustomerDAO customerDAO = new CustomerDAOImpl();

        return customerDAO.addCustomer(customer);
    }

    @Override
    public Customer getCustomer(int customerId) {
        CustomerDAO customerDAO = new CustomerDAOImpl();
        return customerDAO.getCustomer(customerId);
    }

    @Override
    public String updateCustomer(Customer customer) {
        CustomerDAO customerDAO = new CustomerDAOImpl();
        return customerDAO.updateCustomer(customer);
    }

    @Override
    public String deleteCustomer(Integer customerId) {
        CustomerDAO customerDAO = new CustomerDAOImpl();
        return customerDAO.deleteCustomer(customerId);
    }

    @Override
    public List<Customer> getAllCustomers() {
        CustomerDAO customerDAO = new CustomerDAOImpl();
        return customerDAO.getAllCustomers();
    }
}
