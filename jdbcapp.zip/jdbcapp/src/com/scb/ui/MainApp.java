package com.scb.ui;

import com.scb.model.Customer;
import com.scb.service.CustomerService;
import com.scb.service.CustomerServiceImpl;

import java.util.List;

public class MainApp {

    public static void main(String[] args) {
            Customer customer = new Customer();
            customer.setCustomerId(2);
            customer.setCustomerName("John Page");
            customer.setCustomerAddress("123 Main St");
            customer.setCustomerPhone("9999106219");

            CustomerService customerService = new CustomerServiceImpl();
          // String message = customerService.addCustomer(customer);
           // System.out.println(message);

            //Retrieve
            Customer cust = customerService.getCustomer(3);
            System.out.println(cust);

        System.out.println("****************Delete******************");
            //Delete
            String msg = customerService.deleteCustomer(1);
            System.out.println(msg);
            System.out.println("**********************************");
        //Retrieve All customers
        List<Customer> customerList = customerService.getAllCustomers();
        System.out.println(customerList);


    }
}
