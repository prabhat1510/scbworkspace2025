package com.training.utility;

public interface QueryMapper {

    public final static String INSERT_CUSTOMER = "insert into customer values(?,?,?,?,?)";
    public final static String GET_CUSTOMER_BY_ID ="select * from customer where customerId=?" ;
    public final static String UPDATE_CUSTOMER="update customer set contact=? where customerId=?";
}
