package com.training.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectionUtil {
    //private static String username = "postgres";
    private static String username = "root";
    private static String password = "password";
    //private static String url = "jdbc:postgresql://localhost:5432/scbdb";
    private static String url = "jdbc:mysql://localhost:3306/training2025db";

    public static Connection getDBConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}
