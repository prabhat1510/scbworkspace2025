package com.training.service;

import com.training.dao.CustomerDAO;
import com.training.dao.CustomerDAOImpl;
import com.training.model.Customer;

import java.util.List;

public class CustomerServiceImpl implements CustomerService {

    @Override
    public String addCustomer(Customer customer) {
        //Creating custDAO object to access the methods
        CustomerDAO custDAO=new CustomerDAOImpl();
        String result=custDAO.addCustomer(customer); //Calling the DAO layer method
        return result;
    }

    @Override
    public Customer retrieveCustomer(Integer customerId) {
        //Creating custDAO object to access the methods
        CustomerDAO custDAO=new CustomerDAOImpl();
        Customer customer=custDAO.retrieveCustomer(customerId);
        return customer;
    }

    @Override
    public String updateCustomer(Customer customer) {
        CustomerDAO custDAO=new CustomerDAOImpl();
        return custDAO.updateCustomer(customer);
    }

    @Override
    public String deleteCustomer(Integer customerId) {
        CustomerDAO custDAO=new CustomerDAOImpl();
        return custDAO.deleteCustomer(customerId);
    }

    @Override
    public List<Customer> retrieveAllCustomers() {
        CustomerDAO custDAO=new CustomerDAOImpl();
        return custDAO.retrieveAllCustomers();
    }
}
