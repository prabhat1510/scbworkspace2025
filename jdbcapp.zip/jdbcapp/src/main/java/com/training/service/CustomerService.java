package com.training.service;

import com.training.model.Customer;

import java.util.List;

public interface CustomerService {

    //Create
    public String addCustomer(Customer customer);
    //Retrieve
    public Customer retrieveCustomer(Integer customerId);
    //Update
    public String updateCustomer(Customer customer);
    //Delete
    public String deleteCustomer(Integer customerId);
    //Retrieve All
    public List<Customer> retrieveAllCustomers();
}
