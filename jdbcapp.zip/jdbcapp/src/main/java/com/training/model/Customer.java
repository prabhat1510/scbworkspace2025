package com.training.model;

public class Customer {
    private Integer customerId;
    private String customerName;
    private String mailId;
    private String contact;
    private String accountType;
    //No arg constructor

    public Customer() {
    }

    public Customer(Integer customerId, String customerName, String mailId, String contact, String accountType) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.mailId = mailId;
        this.contact = contact;
        this.accountType = accountType;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getMailId() {
        return mailId;
    }

    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                ", mailId='" + mailId + '\'' +
                ", contact='" + contact + '\'' +
                ", accountType='" + accountType + '\'' +
                '}';
    }
}
