package com.training.ui;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;

public class Test {
    public static void main(String[] args) {
        CustomerService customerService=new CustomerServiceImpl();
        /**
        Customer customer=new Customer();
        customer.setCustomerId(3);
        customer.setCustomerName("Ankur");
        customer.setMailId("ankur@a.in");
        customer.setContact("79911225");
        customer.setAccountType("Savings");

        //CustomerService customerService=new CustomerServiceImpl();
        String message =customerService.addCustomer(customer);
        System.out.println(message);**/
        //Retrieve
        Customer customer = customerService.retrieveCustomer(3);
        System.out.println(customer);
        //Retrieve all
        System.out.println(customerService.retrieveAllCustomers());

        /**
        //Delete
        String deleteMessage = customerService.deleteCustomer(3);
        System.out.println(deleteMessage);
         **/
        /**
        //Update
        Customer cust= new Customer();
        cust.setCustomerId(1);
        cust.setAccountType("Savings");
        cust.setContact("9999111144");
        cust.setMailId("dan@a.com");
        cust.setCustomerName("Daniel");
        String updateMessage = customerService.updateCustomer(cust);
        System.out.println(updateMessage);
         */

    }
}
