package com.training.ui;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;

public class Test {
    public static void main(String[] args) {
        CustomerService customerService=new CustomerServiceImpl();
        /**
        Customer customer=new Customer();
        customer.setCustomerId(3);
        customer.setCustomerName("Ankur");
        customer.setMailId("ankur@a.in");
        customer.setContact("79911225");
        customer.setAccountType("Savings");

        //CustomerService customerService=new CustomerServiceImpl();
        String message =customerService.addCustomer(customer);
        System.out.println(message);**/
        //Retrieve
        Customer customer = customerService.retrieveCustomer(3);
        System.out.println(customer);

    }
}
