package com.training.dao;

import com.training.model.Customer;
import com.training.utility.DBConnectionUtil;
import com.training.utility.QueryMapper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAOImpl implements CustomerDAO {
    @Override
    public String addCustomer(Customer customer) {
        //Step 1 -- Make a connection
        Connection conn = DBConnectionUtil.getDBConnection();

        //Step 2 -- Create a statement
        PreparedStatement ps = null;
        try {
            //Assume a valid connection object conn
            conn.setAutoCommit(false);

            ps = conn.prepareStatement(QueryMapper.INSERT_CUSTOMER);
            ps.setInt(1, customer.getCustomerId());
            ps.setString(2, customer.getCustomerName());
            ps.setString(3, customer.getMailId());
            ps.setString(4, customer.getContact());
            ps.setString(5, customer.getAccountType());
        //Step 3 -- Execute the query
            int row = ps.executeUpdate();
            // If there is no error.
            conn.commit();
        //Step 4 -- Get result
            if (row > 0) {
                return "New customer inserted into database";
            }


        //Step 5 -- Close the connection
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            throw new RuntimeException(e);
        }finally {

            try {
                ps.close();
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }



        }
        return "Unable to insert new customer into database";
    }

    @Override
    public Customer retrieveCustomer(Integer customerId) {
        Connection conn = DBConnectionUtil.getDBConnection();
        Customer customer = null;
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.GET_CUSTOMER_BY_ID);
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                customer = new Customer();
                customer.setCustomerId(rs.getInt("customerId"));
                customer.setCustomerName(rs.getString("customerName"));
                customer.setMailId(rs.getString("mailId"));
                customer.setContact(rs.getString("contact"));
                customer.setAccountType(rs.getString("accountType"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return customer;
    }

    @Override
    public String updateCustomer(Customer customer) {
        //Step 1 -- Make a connection
        Connection conn = DBConnectionUtil.getDBConnection();
        //Step 2 -- Create a statement
        try {
            PreparedStatement ps = conn.prepareStatement(QueryMapper.UPDATE_CUSTOMER);
            ps.setInt(2, customer.getCustomerId());
            ps.setString(1, customer.getContact());

            //Step 3 -- Execute the query
            int row = ps.executeUpdate();
            //Step 4 -- Get result
            if (row > 0) {
                return "Customer updated into database";
            }
            ps.close();
            conn.close();

            //Step 5 -- Close the connection
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return "Unable to update customer into database";
    }

    @Override
    public String deleteCustomer(Integer customerId) {
        Connection conn = DBConnectionUtil.getDBConnection();
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("delete from customer where customerId=?");
            ps.setInt(1, customerId);
            int row = ps.executeUpdate();
            if (row > 0) {
                return "Customer deleted from database";
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return "Unable to delete customer from database";
    }

    @Override
    public List<Customer> retrieveAllCustomers() {
        Connection conn = DBConnectionUtil.getDBConnection();
        List<Customer> customers = null;
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from customer");
            //if(rs.next()) {
                customers = new ArrayList<>();
                while(rs.next()) {
                    Customer customer = new Customer();
                    customer.setCustomerId(rs.getInt("customerId"));
                    customer.setCustomerName(rs.getString("customerName"));
                    customer.setMailId(rs.getString("mailId"));
                    customer.setContact(rs.getString("contact"));
                    customer.setAccountType(rs.getString("accountType"));
                    customers.add(customer);
                }
            //}
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return customers;
    }
}
